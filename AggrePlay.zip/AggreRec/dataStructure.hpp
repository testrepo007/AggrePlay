/* 
 * File:   dataStructure.hpp
 * Author: jspawn
 *
 * Created on August 15, 2017, 9:20 PM
 */
#ifndef DATASTRUCTURE_HPP
#define DATASTRUCTURE_HPP

#include "pin.H"
#include <fstream>
#include <vector>
#include <map>

// Force each thread's data to be in its own data cache line so that
// multiple threads do not contend for the same data cache line.
// This avoids the false sharing problem.
#define PADSIZE 56  // 64 byte line size: 64-8

// Structure to model worker Thread in program


//// Structure to hold read Data for each thread
//struct ReadData{    
//    UINT32 RC[20]; // read local data for each thread
//};

// Structure to hold Thread Data. here we include all thread local data
struct ThreadData{
    THREADID tid; //PIN assigned thread ID
    map<ADDRINT, std::pair<vector<UINT32>, std::pair<THREADID, UINT32> > > shadowRead;
    INT32 versionValue; // all reads are thread-local, meaning version values
                        // for different locaitons can be tracked safely together
    UINT8 _pad[PADSIZE];
    UINT32 lockCounter; // Count No. of acquired locks
    UINT32 writeCounter; //Count No. of writes for the thread
    UINT32 readCounter; //Count No. of read for the thread
//    UINT32 Repoch; //to test fasttrack effectiveness
//    bool Rstate; //To track state of read structure. True = Epoch, False = Vector
};

#endif /* DATASTRUCTURE_HPP */