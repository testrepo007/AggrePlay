/* Included for submission for FSE 2019
AggrePlay: Efficient Record and Replay of Multi-threaded
Programs
*/

#include "pin.H"
#include "dataStructure.hpp"
#include <iostream>
#include <fstream>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <stdlib.h>
#include <pthread.h>
#include <utility>
#include <iomanip>
#include <string>
#include <sstream>
#include <vector>
#include "errno.h"
#include <unordered_map>
#include <map>

/*===========================================================
 * Performance Metrics Variables
 ============================================================*/
static double runtime_begin;
static double runtime_end;
static float runtime;

/*===========================================================
 * Program Locks
 ============================================================*/
PIN_LOCK threadLock; // This lock is to protect record of thread start and end
PIN_LOCK writeLock; // This lock is to protect record of writes in the traceFile
//PIN_LOCK readLock; // This lock is to protect record of reads in the traceFile. Not needed in Stride configuration
PIN_LOCK mutexLock; // This lock protects writes to the Lock acquisition log
static TLS_KEY tls_key; //thread local storage key
//ADDRINT * currMemoryWritten; //to temporarily hold memory address being written

using namespace std;

//Vector of Memory locations using memoryData data structure
//std::vector< std::pair<ADDRINT, memoryData> > strideWrites;

//Array of 64 threads with each thread's current attempted lock
ADDRINT currentLocks [64]; // not all will be used and is to serve for programs with up to 64 worker threads. This is to catch real lock acquisitions

//Map of Memory locations using memoryData  data structure
std::unordered_map<ADDRINT, std::pair<vector<std::pair<THREADID, UINT32> >, bool> > memoryMap;

//Map of Memory locations using memoryData  data structure for reads
std::unordered_map<ADDRINT, std::pair<vector<std::pair<THREADID, UINT32> >, bool> > readMemoryMap;

//Map of Lock Acquisition orders by threads using lockData data structure
std::unordered_map<ADDRINT, std::pair<vector<std::pair<THREADID, UINT32> >, bool> > lockMap;

////Map of OS assigned thread ids to PIN assigned thread
std::unordered_map<OS_THREAD_ID,THREADID> threadMap;

//(For inter execution identification)
std::unordered_map<THREADID, std::pair<UINT32, UINT32> > threadAbstract;

/* ================================================================== */
// Global variables 
/* ================================================================== */

UINT32 threadCount = 0;     //total number of threads, including main thread
UINT64 rdOps = 0;           //Number of read operations
UINT32 rd2Opswrite = 0;          //Number of secondary read operations
UINT32 write2Opswrite = 0;          //Number of secondary read operations
UINT64 wrOps = 0;           //Number of write operations
UINT32 lckAcq = 0;          //Number of lock acquisition operations
UINT64 vectorOps = 0;       //Number of vecotr clock operations
UINT64 epochOps = 0;        //Number of epoch operations
INT32 threadFork = 0;       //Number of thread Forks
INT32 threadJoin = 0;       //Number of thread Joins
UINT64 readVec = 0;         //NUmber of vector clock operations
std::ostream * out = &cerr; //Output file stream
ofstream traceFileWrites; //Output file for write event abstraction data FORMAT :MEMLOC THREADID   LOCAL COUNTER
ofstream traceFile; //Output file for execution data 
ofstream traceFileLocks; //Output file for lock event abstraction data FORMAT :LOCK THREADID   LOCAL COUNTER
ofstream traceFileThreads; //Output file for thread abstraction data FORMAT :MEMLOC THREADID   LOCAL COUNTER
ofstream traceFileReads; //output read values for each read for each thread
ofstream traceFileReadWrites; //output read values for each read for each thread

/* ===================================================================== */
// Command line switches
/* ===================================================================== */

KNOB<string> KnobOutputFile(KNOB_MODE_WRITEONCE,  "pintool",
    "o1", "AggSum.out", "specify file name for Stride summary output");

KNOB<string> KnobTraceFileThreads(KNOB_MODE_WRITEONCE,  "pintool",
    "o2", "AggThreads.out", "specify file name for threads"); 

KNOB<string> KnobTraceFileWrites(KNOB_MODE_WRITEONCE,  "pintool",
    "o3", "AggWrites.out", "specify file name for program trace writes"); 

KNOB<string> KnobTraceFileLocks(KNOB_MODE_WRITEONCE,  "pintool",
    "o4", "AggLocks.out", "specify file name for program trace locks acquired for all threads");

KNOB<string> KnobTraceFileReads(KNOB_MODE_WRITEONCE,  "pintool",
    "o6", "AggReads.out", "specify file name for program trace reads by all  threads");

KNOB<string> KnobTraceFileReadWrites(KNOB_MODE_WRITEONCE,  "pintool",
    "o7", "AggReadWrites.out", "specify file name for program trace read writes by all  threads");

KNOB<BOOL>   KnobCount(KNOB_MODE_WRITEONCE,  "pintool",
    "count", "1", "count instructions, basic blocks and threads in the application");

KNOB<string>   KnobDir(KNOB_MODE_WRITEONCE,  "pintool",
    "o5", "", "Output directory for execution data");

const std::string slash = "/";

/* ===================================================================== */
// Utilities
/* ===================================================================== */

/*!
 *  Print out help message.
 */
INT32 Usage(){
    cerr << "This tool is implemented based on publication " << endl <<
            "Stride: Search-Based Deterministic Replay in Polynomial Time via Bounded Linkage" << endl << endl;

    cerr << KNOB_BASE::StringKnobSummary() << endl;

    return -1;
}

/*!
 *  Retrieves data from thread local storage
 * param : THREADID threadid
 */
ThreadData* get_tls(THREADID threadid) {
	ThreadData* tData = static_cast<ThreadData*> (PIN_GetThreadData(tls_key, threadid));
	return tData;
}

/*
 * Updates the read vector for current thread using read vectors of other threads
 * param : THREADID threadid
 */
bool updateReadVectors(THREADID threadid, ADDRINT mem){   
    //if VC, use the VC code else epoch code
    readVec++;
    UINT32 sum = 0; UINT32 i;
    UINT32 td = threadCount;
    //Get the current thread's RC and update it from the other threads values
    ThreadData * currThread = get_tls(threadid);
    map<ADDRINT, std::pair<vector<UINT32>, std::pair<THREADID, UINT32> > >::iterator it = currThread->shadowRead.find(mem);
    if (it != currThread->shadowRead.end() && td > 1){
//        cout << td << " ";
        for (i = 0; i < td; i++){
            if(i != threadid){
                ThreadData * t = get_tls(i);
                map<ADDRINT, std::pair<vector<UINT32>, std::pair<THREADID, UINT32> > >::iterator itt = t->shadowRead.find(mem);               
                if (itt != t->shadowRead.end()){
                    sum += itt->second.first.at(i);
                    it->second.first.at(i) = (it->second.first.at(i) > itt->second.first.at(i)) ? it->second.first.at(i) : itt->second.first.at(i);
                }
            }
        }
    }
    
    return  (sum > 0) ? true : false ;
}

/* ===================================================================== */
// Analysis routines
/* ===================================================================== */

/*!
 * Record Read of memory locations
 * This function is called for every read operation prior to it being executed
 * @param[in]   threadid    ID of executing thread
 * @param[in]   memoryAddr  Memory address to be read
 * 
 * @note use atomic operations for multi-threaded applications
 */
void PIN_FAST_ANALYSIS_CALL onRead(THREADID threadid, ADDRINT memoryAddr){
    ThreadData* t = get_tls(threadid);
    t->readCounter++;
            // get latest version value of this memory location
           map<ADDRINT, std::pair<vector<UINT32>, std::pair<THREADID, UINT32> > >::iterator it = t->shadowRead.find(memoryAddr);
           if (it != t->shadowRead.end()){        // if its in the thread's local memory
               /*(implementation of the last one value predictor)*/
               // if it already exists. update the counter for the thread by 1
               // for the location.
               it->second.first[threadid]++;
           } else {
               // if hasn't been read by current thread before
               //insert record into memoryMap
               vector <UINT32> temp(8,0);        
               t->shadowRead[memoryAddr] = std::make_pair(temp, std::make_pair(0,0)); // insert pair of vector and another pair        
               t->shadowRead[memoryAddr].first[threadid] = 1;
           }
           // Get last write to memoryAddr and save order with read in execution log
           PIN_GetLock(&writeLock, threadid + 1);
           rdOps++;
           unordered_map<ADDRINT, std::pair<vector<std::pair<THREADID, UINT32> > ,bool> >::iterator itt = memoryMap.find(memoryAddr);
           map<ADDRINT, std::pair<vector<UINT32>, std::pair<THREADID, UINT32> > >::iterator ita = t->shadowRead.find(memoryAddr);
           if ((itt != memoryMap.end()) && (itt->second.first.size()  > 0) && (itt->second.first.back().first != t->tid) && (itt->second.first.back().first != ita->second.second.first  && itt->second.first.back().second != ita->second.second.second)){ // optimize to weed out intra-thread dependencies on shared memory locations
               //EXECUTION LOG FORMAT WRITE-READ:  WRITETHREAD   WRITECOUNTER    READ
               traceFileReads << itt->second.first.back().first << "," << itt->second.first.back().second << "," << t->tid << "," << t->readCounter << endl;
           }
           PIN_ReleaseLock(&writeLock);   
   
}

/*!
 * Record Write of memory locations
 * This function is called for every write operation prior to it being executed
 * @param[in]   threadid    ID of executing thread
 * @param[in]   instAddr    Memory address of instruction to be executed
 * @param[in]   memoryAddr  Memory address to be written
 * @param[in]   memorySize  Size of Memory address to be written
 * 
 * @note use atomic operations for multi-threaded applications
 */
void PIN_FAST_ANALYSIS_CALL onWrite(THREADID threadid, ADDRINT memoryAddr){
    ThreadData * t = get_tls(threadid);
    t->writeCounter++;
    PIN_GetLock(&writeLock, threadid +1);
      bool ch = updateReadVectors(threadid, memoryAddr);
      map<ADDRINT, std::pair<vector<UINT32>, std::pair<THREADID, UINT32> > >::iterator iit = t->shadowRead.find(memoryAddr);
      if(iit != t->shadowRead.end() && ch == true){
          traceFileReadWrites << "0x" << std::hex << memoryAddr << "-" << std::dec;
        for (vector<UINT32>::iterator vi = iit->second.first.begin(); vi < iit->second.first.end(); vi++){
            traceFileReadWrites << *vi << ",";
        }

        traceFileReadWrites  <<  threadid  << "," << t->writeCounter << endl;
      }
        // check if a record for the address exists in memoryMap      
        unordered_map<ADDRINT, std::pair<vector<std::pair<THREADID, UINT32> > ,bool> >::iterator it = memoryMap.find(memoryAddr);           
        if (it != memoryMap.end()){//if it already exists                        
            it->second.first.push_back(std::make_pair(threadid, t->writeCounter));
            if(it->second.second == true){
                it->second.second = (t->tid == it->second.first.back().first) ? true : false ;
            }
        } else {
            // if it doesn't exist, create and insert data for it 
            //insert record into memoryMap
            std::vector<std::pair<THREADID, UINT32> > temp;
            temp.push_back(std::make_pair(threadid, t->writeCounter));
            memoryMap[memoryAddr] = std::make_pair(temp,true);
        }
    PIN_ReleaseLock(&writeLock);    
}

/*!
 * Record Lock acquisition order by threads
 * This function is called for every lock operation prior to it being executed
 * @param[in]   threadid    ID of executing thread
 * @param[in]   ADDRINT    Lock about to be acquired
 * @note use atomic operations for multi-threaded applications
 */
void PIN_FAST_ANALYSIS_CALL beforeLockAcquire(THREADID threadid, ADDRINT mutex) {    
        currentLocks[threadid] = mutex; //get thread and current lock operation being attempted
}

/*!
 * Record Lock acquisition order by threads
 * This function is called for every lock operation after its been executed
 * @param[in]   threadid    ID of executing thread
 * @param[in]   ADDRINT    return value of lock acquisition function
 * @note use atomic operations for multi-threaded applications
 */
void PIN_FAST_ANALYSIS_CALL afterLockAcquire(THREADID threadid, ADDRINT returnValue) {
        ThreadData* t = get_tls(threadid);
        t->lockCounter++;
        lckAcq++;
        // check if a record for the address exists in lockData
        unordered_map<ADDRINT, std::pair<vector<std::pair<THREADID, UINT32> >, bool> >::iterator it = lockMap.find(currentLocks[threadid]);
        
        if (it != lockMap.end()){// if it already exists                     
            it->second.first.push_back(std::make_pair(threadid, t->lockCounter));//insert record
            if(it->second.second == true){
                it->second.second = (t->tid == it->second.first.back().first) ? true : false ;
            }
        } else {
            // if it doesn't exist, create and insert data for it     
            std::vector<std::pair<THREADID, UINT32> > temp;
            temp.push_back(std::make_pair(threadid, t->lockCounter));
            lockMap[currentLocks[threadid]] = std::make_pair(temp,true);//insert record into lockData
        }
        currentLocks[threadid] = 0;
}

/* ===================================================================== */
// Instrumentation callbacks
/* ===================================================================== */

/*!
 * Insert call to the CountBbl() analysis routine before every basic block 
 * of the trace.
 * This function is called every time a new trace is encountered.
 * @param[in]   trace    trace to be instrumented
 * @param[in]   v        value specified by the tool in the TRACE_AddInstrumentFunction
 *                       function call
 */
VOID Trace(TRACE trace, VOID *v){
    // Visit every basic block in the trace
    for (BBL bbl = TRACE_BblHead(trace); BBL_Valid(bbl); bbl = BBL_Next(bbl)){
        // Insert a call to CountBbl() before every basic bloc, passing the number of instructions
         for(INS ins = BBL_InsHead(bbl); INS_Valid(ins); ins=INS_Next(ins)){

        	/* From FastTrack-Yan Cai with modifications
        	 * we take part code from ThreadSantizer: InstrumentMopsInBBL.
        	 * http://code.google.com/p/data-race-test/
        	 * */             
        	if(INS_IsAtomicUpdate(ins))continue;
        	if(INS_MemoryOperandCount(ins) == 0)continue;
                if(INS_LockPrefix(ins))continue;
                UINT32 memOperands = INS_MemoryOperandCount(ins);

                for (UINT32 memOp = 0; memOp < memOperands; memOp++){
                    if(INS_MemoryOperandIsRead(ins, memOp)){
                        INS_InsertPredicatedCall(
                                ins, IPOINT_BEFORE, 
                                (AFUNPTR)onRead,
                                IARG_FAST_ANALYSIS_CALL,
                                IARG_THREAD_ID,
                                IARG_MEMORYOP_EA, memOp,
                                IARG_END);
                    }

                     if(INS_MemoryOperandIsWritten(ins, memOp)){
                        INS_InsertPredicatedCall(
                                ins, IPOINT_BEFORE, 
                                (AFUNPTR)onWrite,
                                IARG_FAST_ANALYSIS_CALL,
                                IARG_THREAD_ID,
                                IARG_MEMORYOP_EA, memOp,
                                IARG_END);
                    }       
                }
        }
    }
}

/*!
 * Intrument for pthread related routines in the subject program
 * This function is called every time any of the specified routines are encountered.
 * @param[in]   rtn    routine to be instrumented
 */
VOID InstrumentPthreadRTN(RTN rtn){
	string rtn_name = RTN_Name(rtn);
         if (rtn_name.find("pthread_mutex_lock") != string::npos ||
			rtn_name.find("pthread_mutex_trylock") != string::npos ||
			rtn_name.find("pthread_mutex_timedlock") != string::npos ||
			rtn_name.find("pthread_spin_lock") != string::npos ||
			rtn_name.find("pthread_spin_trylock") != string::npos ||
			rtn_name.find("pthread_rwlock_wrlock") !=string::npos ||
			rtn_name.find("pthread_rwlock_trywrlock") !=string::npos ||
			rtn_name.find("pthread_rwlock_rdlock") !=string::npos ||
			rtn_name.find("pthread_rwlock_tryrdlock" ) !=string::npos) {
		RTN_Open(rtn);                
		RTN_InsertCall(rtn, IPOINT_BEFORE,
				(AFUNPTR) beforeLockAcquire,
				IARG_FAST_ANALYSIS_CALL,
				IARG_THREAD_ID,
				IARG_FUNCARG_ENTRYPOINT_VALUE, 0,
				IARG_END);
                RTN_InsertCall(rtn, IPOINT_AFTER,
				(AFUNPTR) afterLockAcquire,
				IARG_FAST_ANALYSIS_CALL,
				IARG_THREAD_ID,
				IARG_FUNCRET_EXITPOINT_VALUE,
				IARG_END);                        
		RTN_Close(rtn);
	}
}

/*!
 * Insert call to the Images
 * of the trace.
 * This function is called every time a new Image is encountered.
 * @param[in]   image    trace to be instrumented
 * @param[in]   v        value specified by the tool in the IMG_AddInstrumentFunction
 *                       function call
 */
VOID ImageLoad(IMG img, VOID *v){
    //instrument images with pthread primitives
    if (IMG_Name(img).find("libpthread") != string::npos){
    	for (SEC sec = IMG_SecHead(img); SEC_Valid(sec); sec = SEC_Next(sec))
    		for (RTN rtn = SEC_RtnHead(sec); RTN_Valid(rtn); rtn = RTN_Next(rtn)){
    			InstrumentPthreadRTN(rtn);
    		}
    }
}

/*!
 * Increase counter of threads in the application.
 * This function is called for every thread created by the application when it is
 * about to start running (including the root thread).
 * @param[in]   threadIndex     ID assigned by PIN to the new thread
 * @param[in]   ctxt            initial register state for the new thread
 * @param[in]   flags           thread creation flags (OS specific)
 * @param[in]   v               value specified by the tool in the 
 *                              PIN_AddThreadStartFunction function call
 */
VOID ThreadStart(THREADID threadIndex, CONTEXT *ctxt, INT32 flags, VOID *v){
    PIN_GetLock(&threadLock, threadIndex + 1);
        ThreadData *tData = new ThreadData();
        tData->tid = threadIndex;            
        tData->lockCounter = 0;  // initialize lock counter
        tData->writeCounter = 0;  // initialize write counter
        tData->readCounter = 0; // initialize read counter     
        PIN_SetThreadData(tls_key, tData, threadIndex);        
        threadMap[PIN_GetTid()] = threadIndex;
        ++threadCount;    
        if (threadIndex != 0){ // if not main thread
            // store THREADID, <PARENToPARENT,PARENT>            
            traceFileThreads << threadIndex << "," << threadMap[PIN_GetParentTid()] << endl;
        }
    PIN_ReleaseLock(&threadLock);
}

/*!
 * Print out analysis results.
 * This function is called when the application exits.
 * @param[in]   code         447   exit code of the application
 * @param[in]   v               value specified by the tool in the 
 *                              PIN_AddFiniFunction function call
 */
VOID Fini(INT32 code, VOID *v){
    runtime_end = clock();                                                // get end time of application in seconds
    runtime = (float) (runtime_end - runtime_begin) / CLOCKS_PER_SEC;             // Get time in seconds
    *out <<  "===========AGGREREC RECORD PROGRAM RESULTS==============" << endl;
    *out <<  "========================================================" << endl;
    *out <<  "Number of Read instructions: " << rdOps  << endl;
    *out <<  "Number of Lock Acquisitions instructions: " << lckAcq  << endl;
    *out <<  "Number of Write instructions: " << wrOps  << endl;
    *out <<  "Number of threads: " << threadCount  << endl;
    *out <<  "Runtime in seconds: " << runtime  << endl;
    *out <<  "========================================================" << endl;      
      for (unsigned int i = 0; i < threadCount; i++){
        ThreadData* t = get_tls(i);
        t->shadowRead.clear();
    }
    UINT len,i;
    //Output any remaining records to file for lock acquisitions
    for (std::unordered_map<ADDRINT, std::pair<vector<std::pair<THREADID, UINT32> >, bool> >::iterator it = lockMap.begin(); it != lockMap.end(); ++it){
        // FORMAT FOR LOCK LOG FILE = LOCK,THREADID,THREAD_LOCAL_LOCK_COUNTER
        len = it->second.first.size();
        if (len > 1 && it->second.second == false){
            for (i = 0; i < len; i++){
                if( i == len-1 ){
                    traceFileLocks << it->second.first[i].first << "," << it->second.first[i].second;
                } else {
                    traceFileLocks << it->second.first[i].first << "," << it->second.first[i].second << "-";
                }
            }        
        traceFileLocks << endl;
        }
    }
    lockMap.clear();
    traceFileLocks.close();

//    //Output any records to file for write instructions
//    // for each memory location, we output the access order for that location
    for (std::unordered_map<ADDRINT, std::pair<vector<std::pair<THREADID, UINT32> >, bool> >::iterator writ = memoryMap.begin(); writ != memoryMap.end(); ++writ){
        // WRITE LOG FILE FORMAT - MEM_LOCATION,THREAD ID, THREAD_LOCAL_WRITE_COUNTER
        len = writ->second.first.size();
        if (len > 1 && writ->second.second == false){
        for (i = 0; i < len; i++){
            if( i == len-1 ){
                traceFileWrites << writ->second.first[i].first << "," << writ->second.first[i].second;
            } else {
                traceFileWrites << writ->second.first[i].first << "," << writ->second.first[i].second << "-";
            }
        }
        traceFileWrites << endl;
        }
    }   
    memoryMap.clear();
    traceFileWrites.close(); // close the Writes file
//
    traceFileThreads.close(); // Close file for thread abstractions
    
    //finally close the summary output stream *out
    string fileName = KnobOutputFile.Value();
    if (!fileName.empty()){
        delete out;
    }
}

/*!
 * The main procedure of the tool.
 * This function is called when the application image is loaded but not yet started.
 * @param[in]   argc            total number of elements in the argv array
 * @param[in]   argv            array of command line arguments, 
 *                              including pin -t <toolname> -- ...
 */
int main(int argc, char *argv[]){
    // Initialize PIN library. Print help message if -h(elp) is specified
    // in the command line or the command line is invalid 
    if( PIN_Init(argc,argv) ){
        return Usage();
    }
    
    PIN_InitSymbols();//Function symbols.        
    
    PIN_InitLock(&threadLock);//Initialize the pin lock for threads    
    
    PIN_InitLock(&writeLock); //Initialize writeLock
    
    PIN_InitLock(&mutexLock); //Initialize lock for locks
    
    tls_key = PIN_CreateThreadDataKey(0); //Initialize thread local storage
    
    string fileName = KnobDir.Value() + slash + KnobOutputFile.Value();
    
    if (!fileName.empty()) { out = new std::ofstream(fileName.c_str());}
        
    std::string str1 = KnobDir.Value() + slash + KnobTraceFileWrites.Value();
    traceFileWrites.open(str1.c_str(), ios::out | ios::trunc);   
    
    std::string str2 = KnobDir.Value() + slash + KnobTraceFileLocks.Value();
    traceFileLocks.open(str2.c_str(),  ios::out | ios::trunc);    
    
    std::string str3 = KnobDir.Value() + slash + KnobTraceFileThreads.Value();
    traceFileThreads.open(str3.c_str(),  ios::out | ios::trunc);
    
    std::string str4 = KnobDir.Value() + slash + KnobTraceFileReads.Value();
    traceFileReads.open(str4.c_str(),  ios::out | ios::trunc);
    
    std::string str5 = KnobDir.Value() + slash + KnobTraceFileReadWrites.Value();
    traceFileReadWrites.open(str5.c_str(), ios::out | ios::trunc);
    
    if (KnobCount){
        // Register function to be called to instrument traces
        TRACE_AddInstrumentFunction(Trace, 0);
        
        //Register function to be called to instrument image load
        IMG_AddInstrumentFunction(ImageLoad, 0);

        // Register function to be called for every thread before it starts running
        PIN_AddThreadStartFunction(ThreadStart, 0);
        
        // Register function to be called when the application exits
        PIN_AddFiniFunction(Fini, 0);        
    }
    
    cerr <<  "===============================================" << endl;
    cerr <<  "Implementation of AggreRec Record Phase" << endl;
    cerr <<  "===============================================" << endl;
    if (!KnobOutputFile.Value().empty()){
        cerr << "See file " << KnobDir.Value() + slash + KnobOutputFile.Value() << " for summary info" << endl;
        cerr << "See file " << KnobDir.Value() + slash + KnobTraceFileReads.Value() << " for trace reads" << endl;
        cerr << "See file " << KnobDir.Value() + slash + KnobTraceFileWrites.Value() << " for trace writes" << endl;
        cerr << "See file " << KnobDir.Value() + slash + KnobTraceFileReadWrites.Value() << " for trace read-writes" << endl;
        cerr << "See file " << KnobDir.Value() + slash + KnobTraceFileLocks.Value() << " for lock acquisition info" << endl;
    }
    cerr <<  "===============================================" << endl;
    cout << "Subject Program output below:" << endl << endl;
    
    // Save current time 
    runtime = clock();
    
    // Start the program, never returns
    PIN_StartProgram();
    
    return 0;
}
/* ===================================================================== */
/* eof */
/* ===================================================================== */